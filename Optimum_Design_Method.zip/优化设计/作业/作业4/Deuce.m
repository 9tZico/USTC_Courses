function [x, min] = Deuce(no, x0, d, a0, epsilon)
    [a, b, ~] = range(no, x0, d, a0);
    c = (a + b) / 2;
    
    while (abs(b-a)>=epsilon)
        if (abs(f1(no, x0, d, c))>=epsilon)
            if (f1(no, x0, d, c) < 0)
                a = c;
            elseif (f1(no, x0, d, c) > 0)
                b = c;
            end
        else
            break;
        end
        c = (a + b) / 2;
    end

    x = x0 + d*c;

    min = f(no, x0, d, c);
end