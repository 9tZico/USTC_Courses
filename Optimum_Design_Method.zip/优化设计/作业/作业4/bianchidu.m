function [x, min, time, itnum] = bianchidu(algorithm, no, x0, a0, e1, e2)
    tic;                                % 开始计时
    itnum = 0;
    n = 100;    % 最多迭代次数
    d = -g(no, x0);
    H = eye(length(x0));
    d = d * H;
    x1 = x0;
    [x2,~] = fmin(algorithm, no, x1, d, a0, e2);
    k = 0;
    while norm(x2-x1) > e1
        itnum = itnum +1;
        k = k + 1;
        y = g(no, x2) - g(no, x1);
        s = x2 - x1;
        E = (s'*s)/(s*y') - (H*y'*y*H)/(y*H*y');
        H = H + E;
        d = g(no, x2)*H;
        x1 = x2;
        [x2,~] = fmin(algorithm, no, x1, d, a0, e2);
        if k == n
            k = 0;
            x1 = x2;
            d = -g(no, x1);
            H = eye(length(x0));
            d = H * d;
            [x2,~] = fmin(algorithm, no, x1, d, a0, e2);
        end
    end
    x = x2;
    min = f(no,x2,1,0);
    toc;
    time = toc;
end