x = -5:0.1:7;
y = -5:0.1:7;
[X,Y] = meshgrid(x,y);
Z = X.*X + 2.*Y.*Y - 2.*X.*Y - 4*X;
surf(X,Y,Z);
