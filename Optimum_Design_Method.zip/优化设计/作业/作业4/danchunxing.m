function [x, Min, time, itnum] = danchunxing(no, x0, a0, e1)
    tic;
    x0 = x0';
    max_iter = 1000;
    % 参数设置
    rho = 1;   % 反射系数
    chi = 2;   % 扩展系数
    gamma = 0.5;   % 收缩系数
    sigma = 0.5; % 压缩系数
    n = length(x0);
    % 初始化单纯形
    simplex = repmat(x0, 1, n+1);
    for i = 1:n
        simplex(i, i+1) = simplex(i, i+1) + a0;
    end
    % 计算各顶点的函数值
    fv = zeros(1, n+1);
    for i = 1:n+1
        fv(i) = f(no, simplex(:,i), 0, 0);
    end
    iter = 0;
    while iter < max_iter
        % 对顶点进行排序，确定最坏、次坏、最好的索引
        [~, indices] = sort(fv);
        best_idx = indices(1);
        worst_idx = indices(end);
        second_worst_idx = indices(end-1);
        % 计算当前单纯形的平均点（终止条件使用）
        current_centroid = mean(simplex, 2);
        distances = vecnorm(simplex - current_centroid);
        simplex_size = max(distances);
        % 检查终止条件
        if simplex_size < e1
            break;
        end
        % 计算反射中心（去掉最坏点后的平均）
        centroid = mean(simplex(:, indices(1:end-1)), 2);
        % 反射步骤
        xr = centroid + rho*(centroid - simplex(:, worst_idx));
        fr = f(no, xr, 0, 0);
        if fr < fv(best_idx)
            % 反射点比当前最好点好，尝试扩展
            xe = centroid + chi*(xr - centroid);
            fe = f(no, xe, 0, 0);
            if fe < fr
                % 接受扩展点
                simplex(:, worst_idx) = xe;
                fv(worst_idx) = fe;
            else
                % 接受反射点
                simplex(:, worst_idx) = xr;
                fv(worst_idx) = fr;
            end
        elseif fr < fv(second_worst_idx)
            % 反射点比次坏点好，替换最坏点
            simplex(:, worst_idx) = xr;
            fv(worst_idx) = fr;
        else
            % 反射点不优于次坏点，进行收缩
            perform_shrink = false;
            if fr < fv(worst_idx)
                % 外部收缩
                xoc = centroid + gamma*(xr - centroid);
                foc = f(no, xoc, 0, 0);
                if foc < fr
                    simplex(:, worst_idx) = xoc;
                    fv(worst_idx) = foc;
                else
                    perform_shrink = true;
                end
            else
                % 内部收缩
                xic = centroid + gamma*(simplex(:, worst_idx) - centroid);
                fic = f(no, xic, 0, 0);
                if fic < fv(worst_idx)
                    simplex(:, worst_idx) = xic;
                    fv(worst_idx) = fic;
                else
                    perform_shrink = true;
                end
            end
            % 如果收缩失败，进行全体收缩
            if perform_shrink
                for i = 1:n+1
                    if i ~= best_idx
                        simplex(:,i) = simplex(:, best_idx) + sigma*(simplex(:,i) - simplex(:, best_idx));
                        fv(i) = f(no, simplex(:,i), 0, 0);
                    end
                end
            end
        end
        iter = iter + 1;
    end
    % 最优解
    [Min, best_idx] = min(fv);
    x = simplex(:, best_idx);
    x = x';
    toc;
    time = toc;
    itnum = iter;
end