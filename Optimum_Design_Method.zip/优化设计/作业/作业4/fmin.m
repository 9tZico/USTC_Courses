function [x, min] = fmin(algorithm, no, x0, d, a0, epsilon)
    if strcmp(algorithm, 'Golden_Ratio')                                % 黄金分割法
        [x, min] = Golden_Ratio(no, x0, d, a0, epsilon);
    elseif strcmp(algorithm, 'Deuce')                                   % 平分法
        [x, min] = Deuce(no, x0, d, a0, epsilon);
    elseif strcmp(algorithm, 'Success_Failure')                         % 成功-失败法
        [x, min] = Success_Failure(no, x0, d, a0, epsilon);
    end
end