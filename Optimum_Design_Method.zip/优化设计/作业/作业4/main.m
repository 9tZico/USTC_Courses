% 起始点与精度
x0 = [1, 1;                     % 题目1起始点
     -2.5, 4.25;                % 题目2起始点
     5, -3.78];                 % 题目3起始点
e = [0.1;                       % 题目1精度
     0.01;                      % 题目1精度
     0.05];                     % 题目1精度
a0 = 1.3;                       % 初始步长
e2 = 0.005;                     % 一维搜索算法的精度

for i = 1:6
    for j = 1:3
        [x, m, t, it]=fmins(i, 'Golden_Ratio', j, x0(j, :), a0, e(j, 1), e2);
        disp(['Multi-obj opt:', num2str(i), '   obj_f:', num2str(j), '   1D search:Golden_Ratio']);
        disp(['x:', num2str(x), '   min:', num2str(m), '   time:', num2str(t), '   itnum:', num2str(it)]);
        [x, m, t, it]=fmins(i, 'Deuce', j, x0(j, :), a0, e(j, 1), e2);
        disp(['Multi-obj opt:', num2str(i), '   obj_f:', num2str(j), '   1D search:Deuce']);
        disp(['x:', num2str(x), '   min:', num2str(m), '   time:', num2str(t), '   itnum:', num2str(it)]);
        [x, m, t, it]=fmins(i, 'Success_Failure', j, x0(j, :), a0, e(j, 1), e2);
        disp(['Multi-obj opt:', num2str(i), '   obj_f:', num2str(j), '   1D search:Success_Failure']);
        disp(['x:', num2str(x), '   min:', num2str(m), '   time:', num2str(t), '   itnum:', num2str(it)]);
    end
end