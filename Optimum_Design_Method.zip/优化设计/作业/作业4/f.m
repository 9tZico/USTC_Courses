function y = f(no, x0, d, a)
    x = x0 + a*d;
    if no == 1
        y = x(1)*x(1) + 2*x(2)*x(2) - 2*x(1)*x(2) - 4*x(1);
    elseif no == 2
        y = x(1)*x(1)*x(1)*x(1) - 2*x(1)*x(1)*x(2) - 2*x(1)*x(2) + x(1)*x(1) + 2*x(2)*x(2) + 4.5*x(1) - 4*x(2) + 4;
    elseif no == 3
        y = x(1)*x(1)*x(1)*x(1) + x(2)*x(2) - 2*x(1)*x(2);
    end
end