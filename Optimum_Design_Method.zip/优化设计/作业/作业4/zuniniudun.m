function [x, min, time, itnum] = zuniniudun(algorithm, no, x0, a0, e1, e2)
    tic;                                % 开始计时
    itnum = 0;
    x1 = x0;
    x2 = x1 - e1;
    while norm(x2 - x1) > e1
        x1 = x2;
        d = -inv(g2(no, x1))*g(no, x1)';
        d = d';
        [x2,~] = fmin(algorithm, no, x1, d, a0, e2);
        itnum = itnum + 1;
    end
    x = x2;
    min = f(no,x2,1,0);
    toc;
    time = toc;
end