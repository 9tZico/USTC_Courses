function [x, min, time, itnum] = fmins(opt, algorithm, no, x0, a0, e1, e2)
    if opt == 1                                
        [x, min, time, itnum] = zuisuxiajiang(algorithm, no, x0, a0, e1, e2);
    elseif opt == 2                                   
        [x, min, time, itnum] = zuniniudun(algorithm, no, x0, a0, e1, e2);
    elseif opt == 3                         
        [x, min, time, itnum] = gongetidu(algorithm, no, x0, a0, e1, e2);
    elseif opt == 4                                  
        [x, min, time, itnum] = baoweier(algorithm, no, x0, a0, e1, e2);
    elseif opt == 5                
        [x, min, time, itnum] = bianchidu(algorithm, no, x0, a0, e1, e2);
    elseif opt == 6                     
        [x, min, time, itnum] = danchunxing(no, x0, a0, e1);
    end
end