function [x, min, time, itnum] = baoweier(algorithm, no, x0, a0, e1, e2)
    tic;
    x0 = x0';
    n = length(x0);
    S = eye(n);
    x0_k = x0(:);
    iter = 0;
    max_iter = 100;
    while iter < max_iter
        % 沿每个方向进行一维搜索
        x = x0_k;
        delta = zeros(n, 1);  % 存储每个方向上的函数值下降量
        for i = 1:n
            s = S(:, i);
            x_new = fmin(algorithm, no, x', s', a0, e2);
            x_new = x_new';
            delta(i) = f(no, x', 0, 0) - f(no, x_new', 0, 0);  % 计算下降量
            x = x_new;
        end
        xn = x;   % 完成n次一维搜索后的点
        % 计算反射点
        x_n_plus_1 = 2 * xn - x0_k;
        % 确定最大下降量及对应方向
        [delta_m, m] = max(delta);
        f1 = f(no, x0_k', 0, 0);
        f2 = f(no, xn', 0, 0);
        f3 = f(no, x_n_plus_1', 0, 0);
        % 判断共轭方向更新条件
        cond1 = (f3 < f1);
        term1 = (f1 - 2*f2 + f3) * (f1 - f2 - delta_m);
        term2 = 0.5 * delta_m * (f1 - f3)^2;
        cond2 = (term1 < term2);
        if cond1 && cond2
            % 沿d_k方向进行搜索
            dk = xn - x0_k;
            x_n_plus_2 = fmin(algorithm, no, xn', dk', a0, e2);
            x_n_plus_2 = x_n_plus_2';
            x0_new = x_n_plus_2;
            % 更新方向向量组（移除第m个方向，添加dk）
            S = [S(:,1:m-1), S(:,m+1:end), dk/norm(dk)];  % 归一化新方向
        else
            % 选择下一轮的初始点
            if f2 <= f3
                x0_new = xn;
            else
                x0_new = x_n_plus_1;
            end
        end
        % 检查收敛条件
        if norm(x0_new - x0_k) < e1
            break;
        end
        % 更新迭代变量
        x0_k = x0_new;
        iter = iter + 1;
    end
    x = x0_k';
    min = f(no, x, 0, 0);
    toc;
    time = toc;
    itnum = iter;
end