function [x, min] = Golden_Ratio(no, x0, d, a0, epsilon)
    [a, b, ~] = range(no, x0, d, a0);   % ~表示无需接收返回值
    lambda = 0.618;                     % λ

    a1 = b - lambda * (b - a);
    y1 = f(no, x0, d, a1);
    a2 = a + lambda * (b - a);
    y2 = f(no, x0, d, a2);

    itnum = 0;                          % 迭代次数

    if (y1 >= y2)
        a = a1;
        a1 = a2;
        y1 = y2;

        a2 = a + lambda * (b - a);
        y2 = f(no, x0, d, a2);
    else
        b = a2;
        a2 = a1;
        y2 = y1;

        a1 = b - lambda * (b - a);
        y1 = f(no, x0, d, a1);
    end

    while (abs(1-a/b)>=epsilon && abs(1-y1/y2)>=epsilon)
        if (y1 >= y2)
            a = a1;
            a1 = a2;
            y1 = y2;

            a2 = a + lambda * (b - a);
            y2 = f(no, x0, d, a2);
        else
            b = a2;
            a2 = a1;
            y2 = y1;

            a1 = b - lambda * (b - a);
            y1 = f(no, x0, d, a1);
        end
        itnum = itnum + 1;
    end
    aa = (a + b) / 2;
    x = x0 + d*aa;
    min = f(no, x0, d, aa);
    
end