function [x, min] = Success_Failure(no, x0, d, a0, epsilon)
    flag = 1;                               % 是否失败过的标志
    h = d;
    x1 = x0 + h*a0;
    y0 = f(no, x0, d, 0);
    y1 = f(no, x1, d, 0);
    if (y0 < y1)
        a = -a0;
        x0 = x1;
    else
        a = a0;
    end

    while 1
        x1 = x0 + h*a;
        if (f(no, x1, d, 0) < f(no, x0, d, 0) && flag)
            a = 2*a;
            x0 = x1;
        elseif (f(no, x1, d, 0) < f(no, x0, d, 0) && ~flag)
            x0 = x1;
        elseif (f(no, x1, d, 0) > f(no, x0, d, 0))
            flag = 0;
            if (abs(a) < epsilon)
                break;
            else
                a = -a / 2;
                x0 = x1;
            end
        end
    end

    x = x0;
    min = f(no, x, d, 0);
end