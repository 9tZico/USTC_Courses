function [x, min, time, itnum] = Golden_Ratio(y, x0, epsilon)
    tic;                                % 开始计时
    [a, b, ~] = interval(y, x0);        % ~表示无需接收返回值
    lambda = 0.618;                     % λ

    a1 = b - lambda * (b - a);
    y1 = y(a1);
    a2 = a + lambda * (b - a);
    y2 = y(a2);

    itnum = 0;                          % 迭代次数

    if (y1 >= y2)
        a = a1;
        a1 = a2;
        y1 = y2;

        a2 = a + lambda * (b - a);
        y2 = y(a2);
    else
        b = a2;
        a2 = a1;
        y2 = y1;

        a1 = b - lambda * (b - a);
        y1 = y(a1);
    end

    while (abs(1-a/b)>=epsilon && abs(1-y1/y2)>=epsilon)
        if (y1 >= y2)
            a = a1;
            a1 = a2;
            y1 = y2;

            a2 = a + lambda * (b - a);
            y2 = y(a2);
        else
            b = a2;
            a2 = a1;
            y2 = y1;

            a1 = b - lambda * (b - a);
            y1 = y(a1);
        end
        itnum = itnum + 1;
    end
    x = (a + b) / 2;
    min = y(x);
    toc;
    time = toc;
end