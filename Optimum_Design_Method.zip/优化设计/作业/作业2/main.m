% 起始点与精度
x1_0 = 3;
x2_0 = 100;
x3_0 = 50;

epsilon1 = 0.01;
epsilon2 = 0.01;
epsilon3 = 0.01;

% 题目1调用六种方法
[gr_x1, gr_min1, gr_time1, gr_itnum1] = fmin('Golden_Ratio', @y1, x1_0, epsilon1);
[de_x1, de_min1, de_time1, de_itnum1] = fmin('Deuce', @y1, x1_0, epsilon1);
[sf_x1, sf_min1, sf_time1, sf_itnum1] = fmin('Success_Failure', @y1, x1_0, epsilon1);
[ne_x1, ne_min1, ne_time1, ne_itnum1] = fmin('Newton', @y1, x1_0, epsilon1);
[qi_x1, qi_min1, qi_time1, qi_itnum1] = fmin('Quadratic_Interpolation', @y1, x1_0, epsilon1);
[ci_x1, ci_min1, ci_time1, ci_itnum1] = fmin('Cubic_Interpolation', @y1, x1_0, epsilon1);

% 题目2调用六种方法
[gr_x2, gr_min2, gr_time2, gr_itnum2] = fmin('Golden_Ratio', @y2, x2_0, epsilon2);
[de_x2, de_min2, de_time2, de_itnum2] = fmin('Deuce', @y2, x2_0, epsilon2);
[sf_x2, sf_min2, sf_time2, sf_itnum2] = fmin('Success_Failure', @y2, x2_0, epsilon2);
[ne_x2, ne_min2, ne_time2, ne_itnum2] = fmin('Newton', @y2, x2_0, epsilon2);
[qi_x2, qi_min2, qi_time2, qi_itnum2] = fmin('Quadratic_Interpolation', @y2, x2_0, epsilon2);
[ci_x2, ci_min2, ci_time2, ci_itnum2] = fmin('Cubic_Interpolation', @y2, x2_0, epsilon2);

% 题目3调用六种方法
[gr_x3, gr_min3, gr_time3, gr_itnum3] = fmin('Golden_Ratio', @y3, x3_0, epsilon3);
[de_x3, de_min3, de_time3, de_itnum3] = fmin('Deuce', @y3, x3_0, epsilon3);
[sf_x3, sf_min3, sf_time3, sf_itnum3] = fmin('Success_Failure', @y3, x3_0, epsilon3);
[ne_x3, ne_min3, ne_time3, ne_itnum3] = fmin('Newton', @y3, x3_0, epsilon3);
[qi_x3, qi_min3, qi_time3, qi_itnum3] = fmin('Quadratic_Interpolation', @y3, x3_0, epsilon3);
[ci_x3, ci_min3, ci_time3, ci_itnum3] = fmin('Cubic_Interpolation', @y3, x3_0, epsilon3);