function [x_min, min, time, itnum] = Deuce(y, x0, epsilon)
    % 这里就认为epsilon1 = epsilon2了
    tic;
    itnum = 0;

    % 对函数y求导，y可以理解成这个函数的"数值"，其中变量x只能以数值形式出现。
    % syms x; f = y(x);将数值转换为变量，可以使用diff函数对其求导
    syms x;
    f = y(x);
    df = diff(f, x);
    df_func = matlabFunction(df);       % 将df函数转换为句柄，df(2)不会输出数值，
                                        % 这有这样才会输出数值

    [a, b, ~] = interval(y, x0);
    c = (a + b) / 2;
    
    while (abs(b-a)>=epsilon)
        if (abs(df_func(c))>=epsilon)
            if (df_func(c) < 0)
                a = c;
            elseif (df_func(c) > 0)
                b = c;
            end
        else
            break;
        end
        c = (a + b) / 2;
        itnum = itnum + 1;
    end

    x_min = c;
    min = y(c);

    toc;
    time = toc;
end