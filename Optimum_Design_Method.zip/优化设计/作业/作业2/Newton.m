function [x_min, min, time, itnum] = Newton(y, x0, epsilon)
    tic;
    itnum = 0;

    [~, a0, ~] = interval(y, x0);

    syms x;
    f = y(x);
    df = diff(f, x);
    ddf = diff(f, x, 2);
    df_func = matlabFunction(df);
    ddf_func = matlabFunction(ddf);
    

    a1 = a0 - df_func(a0) / ddf_func(a0);

    while (abs(a1-a0) > epsilon)
        a0 = a1;
        a1 = a0 - df_func(a0) / ddf_func(a0);
        itnum = itnum + 1;
    end
    x_min = a1;
    min = y(a1);

    toc;
    time = toc;
end