function f = y2(x)
    f = x.*x + exp(-x); 
end