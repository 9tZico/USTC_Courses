function [x, min, time, itnum] = Success_Failure(y, x0, epsilon)
    tic;
    itnum = 0;

    flag = 1;                               % 是否失败过的标志
    h = 1;
    x1 = x0 + h;
    if (y(x0) < y(x1))
        h = -h;
        x0 = x1;
    end

    while 1
        x1 = x0 + h;
        if (y(x1) < y(x0) && flag)
            h = 2*h;
            x0 = x1;
        elseif (y(x1) < y(x0) && ~flag)
            x0 = x1;
        elseif (y(x1) > y(x0))
            flag = 0;
            if (abs(h) < epsilon)
                break;
            else
                h = -h / 4;
                x0 = x1;
            end
        end
        itnum = itnum + 1;
    end

    x = x0;
    min = y(x);
    toc;
    time = toc;
end