function [x_min, min, time, itnum] = Cubic_Interpolation(y, x0, epsilon)
    tic;
    itnum = 0;

    [a, b, ~] = interval(y, x0);

    syms x;
    f = y(x);
    df = diff(f, x);
    df_func = matlabFunction(df);
    
    u = df_func(b);
    v = df_func(a);
    s = 3 * (y(b) - y(a)) / (b - a);
    z = s - u - v;
    w = sqrt(z - u*v);
    alpha = a + (b - a)*(1- (u + w + z) / (u - v + 2*w));
    while (df_func(alpha) > epsilon)
        if (df_func(alpha) < 0)
            a = alpha;
        elseif (df_func(alpha) > 0)
            b = alpha;
        end
        u = df_func(b);
        v = df_func(a);
        s = 3 * (y(b) - y(a)) / (b - a);
        z = s - u - v;
        w = sqrt(z - u*v);
        alpha = a + (b - a)*(1- (u + w + z) / (u - v + 2*w));
        itnum = itnum + 1;
    end

    x_min = alpha;
    min = y(alpha);

    toc;
    time = toc;
end