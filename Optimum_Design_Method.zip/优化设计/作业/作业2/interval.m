function [a, b, h] = interval(y, x0)
    h = 1;                          % 初始步长为1
    a1 = x0;
    y1 = y(a1);
    a2 = x0 + h;
    y2 = y(a2);
    
    if (y1 <= y2)
        h = -h;
        a3 = a1;
        y3 = y1;

        a1 = a2;
        y1 = y2;
        a2 = a3;
        y2 = y3;

        a3 = a2 + h;
        y3 = y(a3);
    else
        a3 = a2 + h;
        y3 = y(a3);
    end

    while (y3 < y2)
        h = 2*h;

        a1 = a2;
        y1 = y2;
        a2 = a3;
        y2 = y3;

        a3 = a2 + h;
        y3 = y(a3);
    end

    a = min(a1, a3);
    b = max(a1, a3);
end