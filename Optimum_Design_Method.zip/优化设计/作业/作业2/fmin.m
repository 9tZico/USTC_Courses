function [x, min, time, itnum] = fmin(algorithm, y, x0, epsilon)
    if strcmp(algorithm, 'Golden_Ratio')                                % 黄金分割法
        [x, min, time, itnum] = Golden_Ratio(y, x0, epsilon);
    elseif strcmp(algorithm, 'Deuce')                                   % 平分法
        [x, min, time, itnum] = Deuce(y, x0, epsilon);
    elseif strcmp(algorithm, 'Success_Failure')                         % 成功-失败法
        [x, min, time, itnum] = Success_Failure(y, x0, epsilon);
    elseif strcmp(algorithm, 'Newton')                                  % 牛顿法
        [x, min, time, itnum] = Newton(y, x0, epsilon);
    elseif strcmp(algorithm, 'Quadratic_Interpolation')                 % 二次插值法
        [x, min, time, itnum] = Quadratic_Interpolation(y, x0, epsilon);
    elseif strcmp(algorithm, 'Cubic_Interpolation')                     % 三次插值法
        [x, min, time, itnum] = Cubic_Interpolation(y, x0, epsilon);
    end
end