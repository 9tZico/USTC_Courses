function f = y3(x)
    f = 5.*x.*x.*x.*x - 4.*x + 8;
end