function f = y1(x)
    f = x*x*x*x - 4*x*x*x - 6*x*x - 16*x + 4;
end