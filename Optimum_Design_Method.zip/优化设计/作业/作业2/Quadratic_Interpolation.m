function [x, min, time, itnum] = Quadratic_Interpolation(y, x0, epsilon)
    tic;
    itnum = 0;

    [a1, a3, h] = interval(y, x0);
    a2 = (a1 + a3) / 2;

    c1 = (y(a3) - y(a1)) / (a3 - a1);
    c2 = ((y(a2) - y(a1)) / (a2 - a1) - c1) / (a2 - a3);

    ap = 0.5 * (a1 + a3 - c1 / c2);

    yp = y(ap);

    while (abs(1-yp/y(a2)) >= epsilon)
        if ((ap - a2) * h > 0)
            if (y(a2) >= yp)
                a1 = a2;
                a2 = ap;
            else
                a3 = ap;
            end
        else
            if (y(a2) >= yp)
                a3 = a2;
                a2 = ap;
            else
                a1 = ap;
            end
        end
        c1 = (y(a3) - y(a1)) / (a3 - a1);
        c2 = ((y(a2) - y(a1)) / (a2 - a1) - c1) / (a2 - a3);

        ap = 0.5 * (a1 + a3 - c1 / c2);

        yp = y(ap);
        itnum = itnum + 1;
    end

    if (y(a2) < yp)
        x = a2;
    else
        x = ap;
    end
    min = y(x);

    toc;
    time = toc;
end