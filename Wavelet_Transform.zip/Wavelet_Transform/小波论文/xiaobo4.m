%适当改进基于离散余弦变换的小波去噪算法
clear
clc
init = 2055615866;
randn('seed',init);
img = imread('nana.png');
X = double(img);
x = X + 10*randn(size(X));%噪声
x = uint8(x);
[h,w,c] = size(x);
R_channel = x(:,:,1);
G_channel = x(:,:,2);
B_channel = x(:,:,3);

outimg1 = block_dct(R_channel,8,3);
outimg2 = block_dct(G_channel,8,3);
outimg3 = block_dct(B_channel,8,3);
[h,w] = size(outimg1)
outimg = zeros([h,w,3]);
outimg(:,:,1) = outimg1;
outimg(:,:,2) = outimg2;
outimg(:,:,3) = outimg3;

subplot(121)
imshow(x);
xlabel('噪声图像');
subplot(122)
imshow(uint8(outimg))
xlabel('分块DCT去噪');


