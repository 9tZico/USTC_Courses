%基于小波变换的模极大值法去噪算法
clear
clc
I = imread('nana.png', 'png');        % 读入图像
X = im2double(I);                           % 转换成双精度类型
x_noise = noise(X,'gaussian', 0.01);       % 加入高斯噪声
% 提取三个通道信息
xr = x_noise(:, :, 1);                      % R通道
xg = x_noise(:, :, 2);                      % G通道
xb = x_noise(:, :, 3);                      % B通道
%基于小波变换的模极大值法
[Cr, Sr] = wavedec2(xr, 2, 'sym4');
[Cg, Sg] = wavedec2(xg, 2, 'sym4');
[Cb, Sb] = wavedec2(xb, 2, 'sym4');
thr_lvd_r = momax(Cr, Sr);         % R通道局部阈值
thr_lvd_g = momax(Cg, Sg);         % G通道局部阈值
thr_lvd_b = momax(Cb, Sb);         % B通道局部阈值
x_soft_lvd_r = wdenoise(xr, 'lvd', 's', thr_lvd_r, 'sym4', 2);
x_soft_lvd_g = wdenoise(xg, 'lvd', 's', thr_lvd_g, 'sym4', 2);
x_soft_lvd_b = wdenoise(xb, 'lvd', 's', thr_lvd_b, 'sym4', 2);
x_soft_lvd = cat(3, x_soft_lvd_r, x_soft_lvd_g, x_soft_lvd_b); 

figure;
imshow(I);
title('原始图像')

figure;
subplot(121)
imshow(x_noise);    title('噪声图像');
subplot(122)
imshow(x_soft_lvd); title('模极大值去噪');