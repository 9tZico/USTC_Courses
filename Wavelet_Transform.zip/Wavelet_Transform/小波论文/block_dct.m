function  [output]=block_dct(input,block_size,stride)
[m n]=size(input);
output=zeros(m,n);
d1 = stride - mod(m-block_size,stride);
d2 = stride - mod(m-block_size,stride);
f1 = mod(d1,block_size);
f2 = mod(d2,block_size);
input2 = padarray(input,[f1 f2],'replicate','post');
[m1 n1]=size(input2);
output2=zeros(m1,n1);
count2=zeros(m1,n1);
num1 = (m1-block_size)/stride + 1;
num2 = (n1-block_size)/stride + 1;
block_num = int32(num1*num2)
block_img = zeros([block_size,block_size,block_num]);
for i = 1:num1
    for j = 1:num2
        index = int32((i-1)*num2+j);
        stax = int32(((i-1)*stride+1));
        endx = int32((i-1)*stride+block_size);
        stay = int32((j-1)*stride+1);
        endy = int32((j-1)*stride+block_size);
        block_img(:,:,index) = input2(stax:endx,stay:endy);
        block_img(:,:,index) = dct_denoise(block_img(:,:,index));
    end
end

for i = 1:num1
    for j = 1:num2
        index = int32((i-1)*num2+j);
        stax = int32(((i-1)*stride+1));
        endx = int32((i-1)*stride+block_size);
        stay = int32((j-1)*stride+1);
        endy = int32((j-1)*stride+block_size);
        output2(stax:endx,stay:endy)=output2(stax:endx,stay:endy)+block_img(:,:,index);
        count2(stax:endx,stay:endy) = count2(stax:endx,stay:endy)+ ones(block_size,block_size);
    end
end
output2 = output2./ count2;
output =  output2(1:m,1:n);
end


function  [output]=dct_denoise(input)
thr = std(input(:))*1.5;
dctgrayImage=dct2(input);
[h,w] = size(dctgrayImage);
h = int32(h);
w = int32(w);
for i = 1:h
    for j = 1:w
        if dctgrayImage(i,j)<thr
            dctgrayImage(i,j)=0;
        end
    end
end
output=idct2(dctgrayImage);
end
