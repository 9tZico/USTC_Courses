%基于主成分分析的小波去噪算法
clear;
clc;
A = imread('nana.png');            %读取图像  
A=imnoise(A,'salt & pepper',0.05);%加入椒盐噪声
subplot(121)
imshow(A); title('加噪图像');
k = PCA_Process(A);                      
subplot(122)
imshow(k,[]);title('去噪图片'); 
