%基于小波变换的相关法去噪算法
clear
clc
I = imread('nana.png', 'png');        % 读入图像
X = im2double(I);                           % 转换成双精度类型
x_noise = noise(X,'gaussian', 0.01);       % 加入高斯噪声
% 提取三个通道信息
xr = x_noise(:, :, 1);                      % R通道
xg = x_noise(:, :, 2);                      % G通道
xb = x_noise(:, :, 3);                      % B通道
%   小波变换去相关计算阈值
thr_r = xiangguan(xr); % R通道全局阈值
thr_g = xiangguan(xg); % G通道全局阈值
thr_b = xiangguan(xb); % B通道全局阈值
x_soft_r = wdenoise(xr, 'gbl', 's', thr_r, 'sym4', 2);
x_soft_g = wdenoise(xg, 'gbl', 's', thr_g, 'sym4', 2);
x_soft_b = wdenoise(xb, 'gbl', 's', thr_b, 'sym4', 2);
x_soft = cat(3, x_soft_r, x_soft_g, x_soft_b);  
subplot(121)
imshow(x_noise);    title('噪声图像');
subplot(122)
imshow(x_soft); title('相关法去噪');