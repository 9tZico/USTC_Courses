%***********PCAȥ�뺯��******************%
function denoise = PCA_Process(im,thr)
% im: ��Ҫȥ���ͼ��
% thr: ��ֵ��Χ (0,0.99)
% output
% denoise: denoised image
% demo
if nargin<2
    thr=0.9; %default thr =0.5;
end
if thr>1||thr<0
    error('threhold shoulf be range from 0 to 0.5')
end
[len,wid,chan]=size(im);
pdenoise=zeros(len,wid,chan);
for i =1 : chan
    img=double(im(:,:,i));
    [U,D,V] = svd(img,0);
    D = diag(D);
     threshold=prctile(abs(D),100*thr); 
    flag = D-threshold;
    idx = find(flag>0);
    pdenoise(:,:,i) = U(:,idx)*diag(D(idx))*V(:,idx)';
end
denoise=uint8(pdenoise);
end
