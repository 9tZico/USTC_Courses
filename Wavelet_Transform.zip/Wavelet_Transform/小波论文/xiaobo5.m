%基于最大熵原理的小波去噪算法
clear
clc
I = imread('nana.png');  
X = rgb2gray(I);  
X=imnoise(X,'salt & pepper',0.05);%加入椒盐噪声
vHist=imhist(X);                                      %得到灰度直方图
[m,n]=size(X);  
p=vHist(find(vHist>0))/(m*n); %求每一不为零的灰度值的概率  
Pt=cumsum(p);   %计算出选择不同t值时，A区域的概率  
Ht=-cumsum(p.*log(p)); %计算出选择不同t值时，A区域的熵  
HL=-sum(p.*log(p));   %计算出全图的熵  
Yt=log(Pt.*(1-Pt)+eps)+Ht./(Pt+eps)+(HL-Ht)./(1-Pt+eps);    %计算出选择不同t值时，判别函数的值  
th=max(Yt);    % th即为最佳阈值  

[height width]=size(X);
X=im2double(X);
Y1=double(X);
A=imnoise(X,'salt & pepper',0.05);%加入椒盐噪声
wname='sym3 ';
n=3;
[c,s]=wavedec2(A,n,wname);
for i=1:3
step(i)=s((i+1),1)*s((i+1),2);  %得到高频每层分解系数的长度
end
num(1,1)=s(1,1)*s(1,2)+1; %获取各层各高频分量在c向量中的坐标  H|V|D
num(1,2)=num(1,1)+s(2,1)*s(2,2);
num(1,3)=num(1,2)+s(2,1)*s(2,2);
num(2,1)=num(1,3)+s(2,1)*s(2,2);
num(2,2)=num(2,1)+s(3,1)*s(3,2);
num(2,3)=num(2,2)+s(3,1)*s(3,2);
num(3,1)=num(2,3)+s(3,1)*s(3,2);
num(3,2)=num(3,1)+s(4,1)*s(4,2);
num(3,3)=num(3,2)+s(4,1)*s(4,2);
%m=0.02;
C=c;
Y=c;
for i=1:3
[H,V,D]=detcoef2('a',c,s,i);%提取第i层各高频系数,提取二维信号小波分解的细节分量
B=[H V D];
[L,T]=size(B);
for k=1:L
    for w=1:T
        sigma=median(abs(B(k,w)))/0.6745;%噪声方差
    end
end

ch=c(1,num(4-i,1):num(4-i,3)+step(4-i)-1);%确定高频系数的范围，为下一步阈值处理和更新高频系数做准备
chl=length(ch);
for j=1:chl
    if abs(ch(j))>=th
        ch(j)=sign(ch(j))*(abs(ch(j))-th);%软阈值处理函数
    else
        ch(j)=0;
    end
end
C(1,num(4-i,1):num(4-i,3)+step(4-i)-1)=ch(1,1:chl);   
end
X0=waverec2(C,s,wname);
 
figure
subplot(121);imshow(X);title('加噪图像')
subplot(122);imshow(X0,[]);title('最大熵法去噪后图像')
