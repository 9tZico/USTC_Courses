%基于小波变换的阈值收缩法去噪算法
clear
clc
I=imread('nana.png');
X = im2double(I);                           % 转换成双精度类型
x_noise = noise(X, 'gaussian', 0.01);       % 加入高斯噪声
% 提取三个通道信息
xr = x_noise(:, :, 1);  % R通道
xg = x_noise(:, :, 2);  % G通道
xb = x_noise(:, :, 3);  % B通道
% 估计三个通道的阈值
[Cr, Sr] = wavedec2(xr, 2, 'sym4');
[Cg, Sg] = wavedec2(xg, 2, 'sym4');
[Cb, Sb] = wavedec2(xb, 2, 'sym4');
x_r = den(xr, 'sym4', 2);
x_g = den(xg, 'sym4', 2);
x_b = den(xb, 'sym4', 2);
x = cat(3, x_r, x_g, x_b);
subplot(121)
imshow(x_noise);title('加噪图像');
subplot(122)
imshow(x);title('去噪后');
