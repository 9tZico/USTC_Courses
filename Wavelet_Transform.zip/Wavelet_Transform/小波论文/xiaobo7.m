%BM3D去噪算法,运行约3分钟，多等会
clear
clc
A = imread('nana.png');            %读取图像  
A=rgb2gray(A);
A=imnoise(A,'salt & pepper',0.05);%加入椒盐噪声
subplot(121)
imshow(A); title('加噪图像');
k = BM3D(A);                      
subplot(122)
imshow(k,[]);title('去噪图片'); 