%% ����
%ErChiDu
clc;
clear;

%�˲���ϵ��
h1=[1,3,3,1];     
h1=sqrt(2)/8*h1;
h2=[-1,3,3,-1];  
h2=sqrt(2)/4*h2;

%��������
m=5;                
M=10;

% ��ʼֵ��ѡ��
f0=linspace(1,1,4);     % 1
f1=linspace(0,2,4);     % 2
figure;
subplot(121);
plot(1:size(f0,2),f0);
subplot(122);
plot(1:size(f1,2),f1);

%% h1
%����
f=f0;
for i=1:m 
    ff=[];
    f=[f,zeros(1,length(f))];
    ff(1,:)=f*h1(1);
    ff(2,:)=[zeros(1,1*2^(i-1)),f(1:length(f)-1*2^(i-1))]*h1(2);
    ff(3,:)=[zeros(1,2*2^(i-1)),f(1:length(f)-2*2^(i-1))]*h1(3);
    ff(4,:)=[zeros(1,3*2^(i-1)),f(1:length(f)-3*2^(i-1))]*h1(4);
    f=sum(ff);
end
x=linspace(0,3,length(f));
figure;
subplot(121);
plot(x,f);
title('h1  5�ξ��ε���');
f=f0;
for i=1:M 
    ff=[];
    f=[f,zeros(1,length(f))];
    ff(1,:)=f*h1(1);
    ff(2,:)=[zeros(1,1*2^(i-1)),f(1:length(f)-1*2^(i-1))]*h1(2);
    ff(3,:)=[zeros(1,2*2^(i-1)),f(1:length(f)-2*2^(i-1))]*h1(3);
    ff(4,:)=[zeros(1,3*2^(i-1)),f(1:length(f)-3*2^(i-1))]*h1(4);
    f=sum(ff);
end
x=linspace(0,3,length(f));
subplot(122);
plot(x,f);
title('h1  10�ξ��ε���');

%���ǵ���
f=f1;
for i=1:m 
    ff=[];
    f=[f,zeros(1,length(f))];
    ff(1,:)=f*h1(1);
    ff(2,:)=[zeros(1,1*2^(i-1)),f(1:length(f)-1*2^(i-1))]*h1(2);
    ff(3,:)=[zeros(1,2*2^(i-1)),f(1:length(f)-2*2^(i-1))]*h1(3);
    ff(4,:)=[zeros(1,3*2^(i-1)),f(1:length(f)-3*2^(i-1))]*h1(4);
    f=sum(ff);
end
x=linspace(0,3,length(f));
figure;
subplot(121);
plot(x,f);
title('h1  5�����ǵ���');
f=f1;
for i=1:M 
    ff=[];
    f=[f,zeros(1,length(f))];
    ff(1,:)=f*h1(1);
    ff(2,:)=[zeros(1,1*2^(i-1)),f(1:length(f)-1*2^(i-1))]*h1(2);
    ff(3,:)=[zeros(1,2*2^(i-1)),f(1:length(f)-2*2^(i-1))]*h1(3);
    ff(4,:)=[zeros(1,3*2^(i-1)),f(1:length(f)-3*2^(i-1))]*h1(4);
    f=sum(ff);
end
x=linspace(0,3,length(f));
subplot(122);
plot(x,f);
title('h1  10�����ǵ���');
%% h2
%���ε���
f=f0;
for i=1:m 
    ff=[];
    f=[f,zeros(1,length(f))];
    ff(1,:)=f*h2(1);
    ff(2,:)=[zeros(1,1*2^(i-1)),f(1:length(f)-1*2^(i-1))]*h2(2);
    ff(3,:)=[zeros(1,2*2^(i-1)),f(1:length(f)-2*2^(i-1))]*h2(3);
    ff(4,:)=[zeros(1,3*2^(i-1)),f(1:length(f)-3*2^(i-1))]*h2(4);
    f=sum(ff);
end
x=linspace(0,3,length(f));
figure;
subplot(121);
plot(x,f);
title('h2  5�ξ��ε���');
f=f0;
for i=1:M 
    ff=[];
    f=[f,zeros(1,length(f))];
    ff(1,:)=f*h2(1);
    ff(2,:)=[zeros(1,1*2^(i-1)),f(1:length(f)-1*2^(i-1))]*h2(2);
    ff(3,:)=[zeros(1,2*2^(i-1)),f(1:length(f)-2*2^(i-1))]*h2(3);
    ff(4,:)=[zeros(1,3*2^(i-1)),f(1:length(f)-3*2^(i-1))]*h2(4);
    f=sum(ff);
end
x=linspace(0,3,length(f));
subplot(122);
plot(x,f);
title('h2  10�ξ��ε���');

%���ǵ���
f=f1;
for i=1:m 
    ff=[];
    f=[f,zeros(1,length(f))];
    ff(1,:)=f*h2(1);
    ff(2,:)=[zeros(1,1*2^(i-1)),f(1:length(f)-1*2^(i-1))]*h2(2);
    ff(3,:)=[zeros(1,2*2^(i-1)),f(1:length(f)-2*2^(i-1))]*h2(3);
    ff(4,:)=[zeros(1,3*2^(i-1)),f(1:length(f)-3*2^(i-1))]*h2(4);
    f=sum(ff);
end
x=linspace(0,3,length(f));
figure;
subplot(121);
plot(x,f);
title('h2  5�����ǵ���');
f=f1;
for i=1:M 
    ff=[];
    f=[f,zeros(1,length(f))];
    ff(1,:)=f*h2(1);
    ff(2,:)=[zeros(1,1*2^(i-1)),f(1:length(f)-1*2^(i-1))]*h2(2);
    ff(3,:)=[zeros(1,2*2^(i-1)),f(1:length(f)-2*2^(i-1))]*h2(3);
    ff(4,:)=[zeros(1,3*2^(i-1)),f(1:length(f)-3*2^(i-1))]*h2(4);
    f=sum(ff);
end
x=linspace(0,3,length(f));
subplot(122);
plot(x,f);
title('h2  10�����ǵ���');