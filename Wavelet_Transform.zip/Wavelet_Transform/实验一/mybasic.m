% 生成小波母函数
function bas = mybasic(t, fc, fb)
    bas = exp(1i*2*pi*fc*t-t.*t/fb) / (pi*fb)^(1/2);
end
