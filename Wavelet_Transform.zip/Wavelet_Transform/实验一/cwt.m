%%
clear;clc;
% 原始小波变换
% 使用示例
dt = 0.001;
t = (0:2/dt-1)*dt;
signal = sawtooth(2*pi*50*t, 0.5);
signal1 = signal;
signal1(1001:end) = 0;
scales = 1:128;
[cfs, times, scales] = custom_cwt(signal1, dt, scales, @(t) mybasic(t, 6, 6, 0));
% 绘制小波变换结果
figure;
imagesc(times, scales, abs(cfs));
xlabel('Time (s)');
ylabel('Scale');
title('原始小波变换');
colorbar;


% 时移
signal2 = signal;
signal2(1:1000) = 0;
[cfs, times, scales] = custom_cwt(signal2, dt, scales, @(t) mybasic(t, 6, 6, 1));
% 绘制小波变换结果
figure;
imagesc(times, scales, abs(cfs));
xlabel('Time (s)');
ylabel('Scale');
title('时移');
colorbar;

% 尺度变换
scales3 = 1:256;
[cfs, times, scales] = custom_cwt(signal1, dt, scales3, @(t) mybasic(t, 6, 6, 0));
% 绘制小波变换结果
figure;
imagesc(times, scales, abs(cfs));
xlabel('Time (s)');
ylabel('Scale');
title('尺度变换');
colorbar;