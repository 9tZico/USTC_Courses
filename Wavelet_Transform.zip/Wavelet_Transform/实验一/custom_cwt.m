% function [cfs, times, scales] = custom_cwt(signal, dt, scales, wavelet_func)
%     % signal: 输入信号
%     % dt: 信号的时间分辨率
%     % scales: 尺度数组
%     % wavelet_func: 小波函数句柄
%     % cfs: 小波系数
%     % times: 时间点
%     % scales: 尺度数组
% 
%     % 初始化输出数组
%     cfs = zeros(length(scales), length(signal));
%     times = (0:length(signal)-1) * dt;
% 
%     % 遍历所有尺度
%     for i = 1:length(scales)
%         s = scales(i);
% 
%         % 遍历所有时间点
%         for j = 1:length(signal)
%             t = j * dt;
% 
%             % 计算卷积
%             cf = 0;
%             for k = 1:length(signal)
%                 cf = cf + signal(k) * wavelet_func((s * (t - k * dt)));
%             end
%             cfs(i, j) = cf / sqrt(s);
%         end
%     end
% end
function cfs = custom_cwt(signal, dt, scales, wavelet_func, tau)
    % 初始化输出
    cfs = zeros(length(scales), length(signal));
    times = (0:length(signal)-1)*dt;
    
    % 遍历所有尺度
    for i = 1:length(scales)
        scale = scales(i);
        
        % 计算小波函数
        wavelet = wavelet_func(scale);
        
        % 遍历所有时间点
        for j = 1:length(signal)
            % 计算小波变换
            cfs(i, j) = sum(signal(j:-1:1) .* wavelet(1:length(signal(j:-1:1)) + tau));
        end
    end
end