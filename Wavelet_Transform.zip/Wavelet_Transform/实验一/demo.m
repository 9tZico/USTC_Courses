function [cfs, times, scales] = custom_cwt(signal, dt, scales, wavelet_func, tau)
    % 初始化输出
    cfs = zeros(length(scales), length(signal));
    times = (0:length(signal)-1)*dt;
    
    % 遍历所有尺度
    for i = 1:length(scales)
        scale = scales(i);
        
        % 计算小波函数
        wavelet = wavelet_func(scale);
        
        % 遍历所有时间点
        for j = 1:length(signal)
            % 计算小波变换
            cfs(i, j) = sum(signal(j:-1:1) .* wavelet(1:length(signal(j:-1:1)) + tau));
        end
    end
end

function wavelet = mybasic(dt, scale, width, tau)
    % 定义基本小波函数
    t = -width/2:dt:width/2;
    wavelet = 1./sqrt(scale) * exp(-0.5 * (t./scale).^2) .* exp(1i * 6 * pi * t + 1i * 2 * pi * tau);
end

% 使用示例
dt = 0.001;
t = (0:2/dt-1)*dt;
signal = sawtooth(2*pi*50*t, 0.5);
signal1 = signal;
signal1(1001:end) = 0;
scales = 1:128;
tau = 0.01; % 定义时间偏移
[cfs, times, scales] = custom_cwt(signal1, dt, scales, @(t, s) mybasic(dt, scales, 2, tau) ,tau);

% 原始图像
figure;
plot(t, signal1);

% 绘制小波变换结果
figure;
imagesc(times, scales, abs(cfs));
xlabel('Time (s)');
ylabel('Scale');
title('时移小波变换');
colorbar;