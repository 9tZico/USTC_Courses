# <center>实验二 mallat算法</center>

## 题目一：

对图像进行二维离散小波变换，变换级数大于等于3级，然后进行阈值化处理(阈值约为10左右)，再统计系数中0的个数 （百分比表示）并进行重构，最后计算重构图像的峰值信噪比(PSNR)。 请用编程（matlab或其他语言均可）完成题目，画出分解图、重构图，给出系数为0的百分比和PSNR，提 交实验报告和代码，实验报告中请给出图像。

### 1. 算法原理

#### 分解

对于二维灰度图像，首先对每一行进行一维离散小波变换（DWT），这会得到水平方向上的低频分量（L）和高频分量（H）。接着，对变换后的数据的每一列进行一维DWT，得到四个不同的分量：低频分量（LL）、水平方向上的低频和垂直方向上的高频（LH）、水平方向上的高频和垂直方向上的低频（HL）以及水平和垂直方向上的高频分量（HH）。

小波变换使用尺度函数（φ）和小波函数（ψ）来分别近似表示信号的低频和高频信息。尺度函数用于构建近似系数，而小波函数用于构建细节系数。

![image-20241105125517704](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105125517704.png)

#### 重构

合成过程是分解过程的逆过程。它从近似系数和细节系数开始，通过逆小波变换重构图像。这个过程涉及到将低频和高频分量重新组合，以恢复原始信号。

在合成过程中，首先对LL、LH、HL和HH分量进行上采样（即增加采样率），然后通过低通滤波器和高通滤波器分别处理，以恢复原始信号的高频和低频成分。

通过将滤波后的分量相加，可以重建原始信号。这个过程可以递归地进行，直到重建完整的原始信号。

![image-20241105125614551](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105125614551.png)

### 2. 编程实现

在对二维图像进行小波变换时，采用Mallat算法来实现快速变换。这个算法首先对图像的每一行进行一维小波变换，以提取近似和差值信息。完成行变换后，再对每一列进行同样的一维小波变换，从而完成对二维信号的一级分解。接着，我们会对新得到的近似系数区域（cc）进行再次的Mallat分解，通过重复这个过程，可以得到图像的多级小波分解。

在图像重建的过程中，采取与分解过程相反的步骤。首先，从最低级别的列开始进行重建，然后对行进行重建，以得到上一级的近似系数（cc）。重复这个过程，直到所有级别的图像都被重建，最终我们可以得到恢复后的原始图像。

本实验需要选择的参数有：分解级数 N=3；阈值的门限值 Th_value=10；小波滤波器类型 filtertypes='sys2'。

算法中首先对图像边沿进行延拓处理；然后逐行、逐列进行卷积分解和下2采样；分解系数达到要求后开始重建，即逐列、逐行进行2插值和卷积；重建达到要求后可以显示图像。然后计算分解0值百分比、PSNR。

分解算法为mallatDe.m；重构算法为mallatRe.m；mallat算法为mallat.m；延拓算法为extension.m。

现在给出main.m代码，与上文一一对应。

```
clear;
clc;

im=imread('LENA.bmp');          %载入图像LENA.bmp
im=double(im);
[imRow,imColum]=size(im);       %计算原始图像信号的系数矩阵大小

subplot(2,2,1);                 %画出原始图像
imshow(uint8(im));
title('原始图像');

N=3;                            %分解的级数
Th_value=10;                    %阈值的门限值
filtertypes='sym2';             %滤波器类型的设定

[imDe,Th_imDe,imRe,filtername,exname,ZeroPer,imDe_mean,imDe_var,zero_num,power,PSNR]=mallat(im,N,Th_value,filtertypes);
% 显示分解后的各级图像分量、统计的零数量、各个子带的均值、方差、零值比例、分解后图像的能量分布、PSNR
subplot(2,2,2);                 %画出分解后图像（数值未阈值化）
imshow(uint8(imDe));
title('分解图像（未阈值化）');

subplot(2,2,3);                 %画出分解后图像（数值经过阈值化）
imshow(uint8(Th_imDe));
title('分解图像（阈值化）');

subplot(2,2,4);                 %画出合成后图像（数值经过阈值化）
imshow(uint8(imRe));
title('还原图像');
%title(strcat('还原图像','滤波器为',filtername,'边界延拓为',exname,' 零值百分比=',num2str(ZeroPer*100),'% PSNR=',num2str(PSNR)));
colormap gray;

figure                          %画出分解后图像的能量分布
[X,Y]=meshgrid(1:size(Th_imDe,1));
mesh(X,Y,power);
title('能量分布');  
```

### 3. 实验结果

在完成四个准备算法的编写后运行main.m，得到分解图和重构图：

![分解重构图](D:\课程\小波变换\实验二\分解重构图.jpg)

能量分布图：

![能量图](D:\课程\小波变换\实验二\能量图.jpg)

N=3时系数为0值的百分比与PSNR：

![image-20241105131712181](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105131712181.png)

## 题目二：

在题目一中，尝试增大变换级数，请问分解后系数中0的百分比会如何变化？ 

现在逐渐增大N，使其分别取4，5，6：

![image-20241105131820052](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105131820052.png)

![image-20241105131847269](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105131847269.png)

![image-20241105131907168](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105131907168.png)

可以看到，分解后系数中0的百分比越来越大。N=3；4；5；6时能量分布图依次如下：

<img src="C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105132142250.png" alt="image-20241105132142250" style="zoom:25%;" /><img src="C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105132211463.png" alt="image-20241105132211463" style="zoom:25%;" /><img src="C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105132245367.png" alt="image-20241105132245367" style="zoom:25%;" /><img src="C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105132313911.png" alt="image-20241105132313911" style="zoom:25%;" />

可以看出能量越来越聚集在低级区域。

## 题目三：

在题目一中，尝试增大阈值，请问PSNR和压缩比会如何变化？

现在令N=3；Th_value依次取10；12；14；16.

![image-20241105132703003](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105132703003.png)

![image-20241105132724105](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105132724105.png)

![image-20241105132742210](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105132742210.png)

![image-20241105132804993](C:\Users\liuzc\AppData\Roaming\Typora\typora-user-images\image-20241105132804993.png)

随着阈值增大，PSNR逐渐减小。

增大阈值意味着更多的小波系数（尤其是高频部分，通常与噪声相关）会被设置为零或者被减小，这会导致在重构图像时丢失更多的信息，从而增加误差，导致PSNR降低；小波变换具有很强的去数据相关性，它能使信号的能量集中在一些大的小波系数中，而噪声的能量分布于整个小波域内。增大阈值可能会导致一些原本属于信号的、但幅值较小的小波系数被错误地视为噪声并被去除或减小，这会增加重构图像与原始图像之间的误差，从而降低PSNR。