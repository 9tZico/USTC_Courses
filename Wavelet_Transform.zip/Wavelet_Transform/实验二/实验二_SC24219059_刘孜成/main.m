clear;
clc;

im=imread('LENA.bmp');          %载入图像LENA.bmp
im=double(im);
[imRow,imColum]=size(im);       %计算原始图像信号的系数矩阵大小

subplot(2,2,1);                 %画出原始图像
imshow(uint8(im));
title('原始图像');

N=3;                            %分解的级数
Th_value=16;                    %阈值的门限值
filtertypes='sym2';             %滤波器类型的设定

[imDe,Th_imDe,imRe,filtername,exname,ZeroPer,imDe_mean,imDe_var,zero_num,power,PSNR]=mallat(im,N,Th_value,filtertypes);
% 显示分解后的各级图像分量、统计的零数量、各个子带的均值、方差、零值比例、分解后图像的能量分布、PSNR
subplot(2,2,2);                 %画出分解后图像（数值未阈值化）
imshow(uint8(imDe));
title('分解图像（未阈值化）');

subplot(2,2,3);                 %画出分解后图像（数值经过阈值化）
imshow(uint8(Th_imDe));
title('分解图像（阈值化）');

subplot(2,2,4);                 %画出合成后图像（数值经过阈值化）
imshow(uint8(imRe));
title('还原图像');
%title(strcat('还原图像','滤波器为',filtername,'边界延拓为',exname,' 零值百分比=',num2str(ZeroPer*100),'% PSNR=',num2str(PSNR)));
colormap gray;

figure                          %画出分解后图像的能量分布
[X,Y]=meshgrid(1:size(Th_imDe,1));
mesh(X,Y,power);
title('能量分布');  

disp(strcat('N= ',num2str(N), ';  Th_value=', num2str(Th_value) ,';  percent 0: ',num2str(ZeroPer*100),'%;  PSNR:',num2str(PSNR)));
