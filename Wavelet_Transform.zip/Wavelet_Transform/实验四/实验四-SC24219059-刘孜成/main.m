clear;
clc;

% 读入图像
im = imread('LENA.bmp');
im = double(im);
[imRow,imColum] = size(im);

% 选择小波
wav = 'coif4';
[LO_D,HI_D,LO_R,HI_R]=wfilters(wav);

% 分解级数
N_o = 3:6;
H = 1:size(N_o,2);
PSNR = 1:size(N_o,2);

for N = N_o
    % 分解
    [imex,exname]=extension(im,length(LO_D));            %对边沿数据进行延拓，使得边沿效果降低
    temp=imex;
    imDe=zeros(size(temp));                              %初始化矩阵，用来存放分解后的信号矩阵
    X=cell(N,4);                                         %存放按块存放的分解系数
    for i=1:N                                                  
        X{i,1}=mallatDe(temp,LO_D,LO_D);                 %低通低通分量
        X{i,2}=mallatDe(temp,HI_D,LO_D);                 %高通低通分量
        X{i,3}=mallatDe(temp,LO_D,HI_D);                 %低通高通分量
        X{i,4}=mallatDe(temp,HI_D,HI_D);                 %高通高通分量
        block=[X{i,1},X{i,2};X{i,3},X{i,4}];             %将四个分量按顺序排列成一个矩阵
        [m,n]=size(block);
        imDe(1:m,1:n)=block;                             %把block置于Q的左上位置
        %temp=X{i,1};
        [temp,exname]=extension(X{i,1},length(LO_D));    %将边沿数据进行延拓，使得边沿效果降低
    end
    
    % 量化
    q = 20;
    Z_k = 1;
    % 计算子带方差
    varLL = var(X{N,1}(:));
    varLH = var(X{N,2}(:));
    varHL = var(X{N,3}(:));
    varHH = var(X{N,4}(:));
    % 计算量化步长
    Q_LL = 1;
    Q_LH = 10 / (q*log(varLH)/log(2));
    Q_HL = 10 / (q*log(varHL)/log(3));
    Q_HH = 10 / (q*log(varHH)/log(4));
    % 量化矩阵初始化
    a_1 = zeros(size(X{N,1}));
    a_2 = zeros(size(X{N,2}));
    a_3 = zeros(size(X{N,3}));
    a_4 = zeros(size(X{N,4}));
    % LL量化
    a_1(X{N,1}>Z_k/2) = 1;
    a_1(X{N,1}<-Z_k/2) = -1;
    % LH量化
    idx21 = find(X{N,2}>Z_k/2);
    idx22 = find(X{N,2}<-Z_k/2);
    a_2(idx21) = ceil((X{N,2}(idx21)-0.5)/Q_LH)+1;
    a_2(idx22) = ceil((X{N,2}(idx22)+0.5)/Q_LH)-1;
    % HL量化
    idx31 = find(X{N,3}>Z_k/2);
    idx32 = find(X{N,3}<-Z_k/2);
    a_3(idx31) = ceil((X{N,3}(idx31)-0.5)/Q_HL)+1;
    a_3(idx32) = ceil((X{N,3}(idx32)+0.5)/Q_HL)-1;
    % HH量化
    idx41 = find(X{N,4}>Z_k/2);
    idx42 = find(X{N,4}<-Z_k/2);
    a_4(idx41) = ceil((X{N,4}(idx41)-0.5)/Q_HH)+1;
    a_4(idx42) = ceil((X{N,4}(idx42)+0.5)/Q_HH)-1;
    
    % 矩阵拼接
    a_q = [a_1, a_2;
           a_3, a_4];
    % 计算熵
    H(N-2) = entropy(a_q);

    % 小波变换恢复图像
    for i=N:-1:1                                                  
        if i>1 
            [m_x,n_x]=size(X{i-1,1});
        else
            [m_x,n_x]=size(im);
        end
        c1=mallatRe(X{i,1},LO_R,LO_R,m_x,n_x);
        c2=mallatRe(X{i,2},HI_R,LO_R,m_x,n_x);
        c3=mallatRe(X{i,3},LO_R,HI_R,m_x,n_x);
        c4=mallatRe(X{i,4},HI_R,HI_R,m_x,n_x);
        c=c1+c2+c3+c4;
        if i>1
            X{i-1,1}=c;
        else
            imRe=c;
        end
    end
    
    e2 = sum(sum((im-imRe).^2))/(imRow*imColum);          %计算恢复图像的方差、PSNR
    PSNR(N-2) = 10*log10(255*255/e2); 
end

figure;
plot(1:size(H,2), H);
figure;
plot(1:size(PSNR,2), PSNR);
