clear;
clc;
iter=10;
wav='db7';
for i = 1:iter
    [phi,psi,xval]=wavefun(wav,iter);
    subplot(2,1,1);
    plot(xval,psi);
    title('�߶Ⱥ���');
    subplot(2,1,2);
    plot(xval,phi);
    title('С������');
end
    
% [phi,g1,xval] = wavefun(wav,iter);
% subplot(2,1,1);
% plot(xval,g1);
% % xlabel('t');
% title('�߶Ⱥ���');
% subplot(2,1,2);
% plot(xval,phi);
% xlabel('t');
% title('С������');
