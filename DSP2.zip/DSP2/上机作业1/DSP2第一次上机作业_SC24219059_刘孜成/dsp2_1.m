clear;clc;
%% 1.
n = 1:1:1024;
N0 = sin(2*pi*n/16+pi/10);
N1 = sqrt(2)*sin(2*pi*n/16);
S = rand(size(n));
S = (S - mean(S))*sqrt(0.05/var(S));

x = N1;
y = S + N0;

rxx_0 = mean(x .* x);
rxx_1 = mean(x(1:end-1) .* x(2:end));
Rxx = [rxx_0, rxx_1;
       rxx_1, rxx_0];
ryx_0 = mean(y .* x);
ryx_1 = mean(y(2:end) .* x(1:end-1));
Ryx = [ryx_0; ryx_1];

h0_vec = -2:0.1:4;                          % 向量形式横坐标
h1_vec = -4:0.1:2;                          % 向量形式纵坐标
h0 = repmat(h0_vec,size(h1_vec,2),1);       % 矩阵形式横坐标
h1 = repmat(h1_vec.', 1, size(h0_vec,2));   % 矩阵形式纵坐标

% 误差性能曲面
J_n = var(y)+(h0.^2+h1.^2)*rxx_0+2*h0.*h1*rxx_1-2*h0*ryx_0-2*h1*ryx_1;

figure;
surf(h0,h1,J_n);                            % 绘制误差性能曲面
figure;
contour(h0,h1,J_n,linspace(0,2,10));        % 绘制等值曲线

%% 2.
H_opt = inv(Rxx)*[ryx_0,ryx_1].';           % 最优滤波器向量
J_min = var(y) - H_opt.'*Rxx*H_opt;         % 最小均方误差

epoch = 100;            % 训练次数
N = 1000;               % 一次训练的迭代次数
delta = 0.1;            % 迭代步长为0.1

H = zeros(2, N);        % 滤波器参数储存矩阵
J = zeros(1, N);        % 均方误差储存向量
VG = zeros(2, N);       % 梯度储存矩阵

for j = 1:1:epoch
    
    S = rand(size(n));
    S = (S - mean(S))*sqrt(0.05/var(S));
    x = N1;
    y = S + N0;

    rxx_0 = mean(x .* x);
    rxx_1 = mean(x(1:end-1) .* x(2:end));
    Rxx = [rxx_0, rxx_1;
          rxx_1, rxx_0];
    ryx_0 = mean(y .* x);
    ryx_1 = mean(y(2:end) .* x(1:end-1));
    Ryx = [ryx_0; ryx_1];
    
    H_temp = zeros(2, N);        % 滤波器参数储存矩阵
    J_temp = zeros(1, N);        % 均方误差储存向量
    VG_temp = zeros(2, N);       % 梯度储存矩阵
    H_temp(:,1) = [3;-4];
    VG_temp(:,1) = 2*Rxx*H_temp(:,1) - 2*Ryx;

    for i = 1:1:N-1
        H_temp(:,i+1) = H_temp(:,i) - 0.5*delta*VG_temp(:,i);                       % 计算下一个滤波器参数
        VG_temp(:,i+1) = 2.*Rxx*H_temp(:,i) - 2.*Ryx;                               % 计算下一个梯度
    end
    for i = 1:1:N
    J_temp(i) = var(y) - 2*Ryx.'*H_temp(:,i) + H_temp(:,i).'*Rxx*H_temp(:,i);       % 计算均方误差
    end
    H = H_temp/epoch + H;
    VG = VG_temp/epoch + VG;
    J = J_temp/epoch + J;
end



%% 3.
figure;
plot(n,S);
S_mean = mean(S);
S_power = var(S);
fprintf('mean: %f\n', S_mean);
fprintf('power (variance): %f\n', S_power);

%% 4.
figure;
contour(h0,h1,J_n,linspace(0,2,10));        % 绘制等值曲线
hold on;
plot3(H(1,1:N),H(2,1:N),J,LineWidth=2);

% 这里有问题了，当迭代步长为0.4时，走的太多了，看起来像是震荡。
% 因此下文步长使用0.1，为了保证收敛，将迭代次数增加到1000
% 更改代码后重新绘制图像，提交时以更改后的代码为准

%% 5.
figure('Name','梯度下降')
plot(1:size(J,2),J,LineWidth=2);

H_LMS = zeros(2, N);        % 滤波器参数储存矩阵
J_LMS = zeros(1, N);        % 均方误差储存向量

for j = 1:1:epoch
    
    S = rand(size(n));
    S = (S - mean(S))*sqrt(0.05/var(S));
    x = N1;
    y = S + N0;

    rxx_0 = mean(x .* x);
    rxx_1 = mean(x(1:end-1) .* x(2:end));
    Rxx = [rxx_0, rxx_1;
          rxx_1, rxx_0];
    ryx_0 = mean(y .* x);
    ryx_1 = mean(y(2:end) .* x(1:end-1));
    Ryx = [ryx_0; ryx_1];
    
    H_temp = zeros(2, N);        % 滤波器参数储存矩阵
    J_temp = zeros(1, N);        % 均方误差储存向量
    VG_temp = zeros(2, N);       % 梯度储存矩阵
    H_temp(:,1) = [3;-4];

    for i = 1:1:N-1
        e = y(i+1) - H_temp(:,i).'*[x(i+1);x(i)];
        H_temp(:,i+1) = H_temp(:,i) + delta*e*[x(i+1);x(i)]; % 计算下一个滤波器参数
    end
    for i = 1:1:N
    J_temp(i) = var(y) - 2*Ryx.'*H_temp(:,i) + H_temp(:,i).'*Rxx*H_temp(:,i);       % 计算均方误差
    end
    H_LMS = H_temp/epoch + H_LMS;
    J_LMS = J_temp/epoch + J_LMS;
end

figure('Name','LMS');
plot(1:size(J_LMS,2),J_LMS,LineWidth=2);

%% 6.
figure;
contour(h0,h1,J_n,linspace(0,2,10));        % 绘制等值曲线
hold on;
plot3(H_LMS(1,1:N),H_LMS(2,1:N),J_LMS,LineWidth=2);

figure;
contour(h0,h1,J_n,linspace(0,2,10));        % 绘制等值曲线
hold on;
plot3(H(1,1:N),H(2,1:N),J,LineWidth=2);
plot3(H_LMS(1,1:N),H_LMS(2,1:N),J_LMS,LineWidth=2);