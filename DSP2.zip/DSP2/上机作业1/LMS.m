clc;clear;
%%
% 1.借助MATLAB画出误差性能曲面和误差性能曲面的等值曲线
n = 1:1:16;                         % 自变量取一个周期
N0 = sin(2*pi*n/16+pi/10);          % N0
N1 = 2^(1/2)*sin(2*pi*n/16);        % N1
S = rand(size(n));                  % 生成均值为0.5，功率为1/12的白噪声
S = (S - mean(S))*sqrt(0.05/var(S)); % 改变白噪声功率和均值

x = N1;
y = S + N0;
k = -15:1:15;                               % 求相关后的自变量
rxx = cos(2*pi*k/16);                       % 正弦干扰信号自相关
ryx = 1/(sqrt(2))*cos(2*pi*k/16+pi/10);     % 宽带信号+正弦干扰与正弦干扰信号互相关
                                            % Q：matlab自带的相关函数算出来的结果和ppt上不一样

h0_vec = -2:0.1:4;                          % 向量形式横坐标
h1_vec = -4:0.1:2;                          % 向量形式纵坐标
h0 = repmat(h0_vec,size(h1_vec,2),1);       % 矩阵形式横坐标
h1 = repmat(h1_vec.', 1, size(h0_vec,2));   % 矩阵形式纵坐标

% 误差性能曲面
J_n = var(y)+(h0.^2+h1.^2)*rxx(0+16)+2*h0.*h1*rxx(1+16)-2*h0*ryx(0+16)-2*h1*ryx(1+16);

figure;
surf(h0,h1,J_n);                            % 绘制误差性能曲面
figure;
contour(h0,h1,J_n,linspace(0,2,10));        % 绘制等值曲线

%%
% 2.写出最陡下降法, LMS算法的计算公式(delta=0.4)
Rxx = [rxx(0+16),rxx(1+16);rxx(1+16),rxx(0+16)];    % 自相关矩阵
Ryx = [ryx(0+16),ryx(1+16)].';                      % 互相关向量
H_opt = inv(Rxx)*[ryx(0+16),ryx(1+16)].';           % 最优滤波器向量
J_min = var(y) - H_opt.'*Rxx*H_opt;                 % 最小均方误差

delta = 0.2;                                        % 训练步长
% i = 1;
% H = zeros(2,100);
% H(:,i) = [3,-4].';
% J = zeros(1,100);
% J(i) = var(y) - 2*Ryx.'*H(:,i) + H(:,i).'*Rxx*H(:,i);
% VG = zeros(2,100);
% VG(:,i) = 2*Rxx*H(:,i) - 2*Ryx;
% while (i <= 100) && ((J(i)-J_min)>0.1)
%     i = i + 1;
%     H(:,i) = H(:,i-1) - (1/2)*delta*VG(i-1);
%     VG(:,i) = 2*Rxx*H(:,i) - 2*Ryx;
%     J(i) = var(y) - 2*Ryx.'*H(:,i) + H(:,i).'*Rxx*H(:,i);
% end
H = zeros(2,100);                                   % 滤波器参数存储矩阵
H(:,1) = [3,-4].';                                  % 滤波器参数初始化
J = zeros(1,100);                                   % 均方误差存储向量
VG = zeros(2,100);                                  % 梯度存储矩阵
VG(:,1) = 2*Rxx*H(:,1) - 2*Ryx;                     % 梯度初始化
% LMS迭代算法
for i = 1:1:100
    J(i) = var(y) - 2*Ryx.'*H(:,i) + H(:,i).'*Rxx*H(:,i);   % 计算均方误差
    H(:,i+1) = H(:,i) - 0.5*delta*VG(:,i);                  % 计算下一个滤波器参数
    VG(:,i+1) = 2.*Rxx*H(:,i) - 2.*Ryx;                     % 计算下一个梯度
end

%%
% 3.用MATLAB产生方差为0.05,均值为0白噪音S(n),并画出其中一次实现的波形图
% 在第1问中已经实现了S(n),只需要考虑在信号的一个周期内的取值，因此n为0-15.现在展示如下：
figure;
stem(n,S);
S_mean = mean(S);
S_power = var(S);
fprintf('mean: %f\n', S_mean);
fprintf('power (variance): %f\n', S_power);

%% 
% 4.
figure;
contour(h0,h1,J_n,linspace(0,2,10));        % 绘制等值曲线
hold on;
plot3(H(1,1:100),H(2,1:100),J,LineWidth=2);

%%
% 5.
J_5 = zeros(1,100);
e_n = zeros(1,100);
n_5 = 1:1:100;
S_5 = rand(size(n_5));                  % 生成均值为0.5，功率为1/12的白噪声
S_5 = (S_5 - mean(S_5))*sqrt(0.05/var(S_5)); % 改变白噪声功率和均值
x_5 = sqrt(2)*sin(2*pi*[n_5,101]/16);
y_5 = S_5 + sin(2*pi*n_5/16+pi/10);
for j = 1:1:100
    H_5 = zeros(2,100);                                     % 滤波器参数存储矩阵
    H_5(:,1) = [3,-4].';                                    % 滤波器参数初始化
    VG_5 = zeros(2,100);                                    % 梯度存储矩阵
    VG_5(:,1) = 2*Rxx*H(:,1) - 2*Ryx;                       % 梯度初始化
    for i = 1:1:100
    J_5(i) = var(y_5) - 2*Ryx.'*H(:,i) + H(:,i).'*Rxx*H(:,i);   % 计算均方误差
    H(:,i+1) = H(:,i) - 0.5*delta*VG(:,i);                      % 计算下一个滤波器参数
    VG(:,i+1) = 2.*Rxx*H(:,i) - 2.*Ryx;                         % 计算下一个梯度
    e_n(i) = y_5(i) - H(:,i).'*[x_5(i+1);x_5(i)];
    end
end
J_5 = J_5/100;
e_n = e_n/100;
figure;
plot(n_5,J_5);
figure;
plot(n_5,e_n)

%%
% 6
H_6 = zeros(2,100);
e_6 = zeros(1,100);
J_6 = zeros(1,100);
for j = 1:1:100
    H_5 = zeros(2,100);                                     % 滤波器参数存储矩阵
    H_5(:,1) = [3,-4].';                                    % 滤波器参数初始化
    for i = 1:1:99
    J_6(i) = var(y_5) - 2*Ryx.'*H_5(:,i) + H_5(:,i).'*Rxx*H_5(:,i);   % 计算均方误差
    e_6(i+1) = y_5(i+1) - H_5(:,i).'*[x_5(i+1);x_5(i)];
    H_5(:,i+1) = H_5(:,i) + delta*e_6(i+1)*[x_5(i+1);x_5(i)];
    end
    H_6 = H_6 + H_5;
end
H_6 = H_6/100;
J_6 = J_6/100;
figure;
contour(h0,h1,J_n,linspace(0,2,10));        % 绘制等值曲线
hold on;
plot3(H_6(1,1:100),H_6(2,1:100),J_6,LineWidth=2);