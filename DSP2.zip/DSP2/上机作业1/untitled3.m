n = 1:1:1024;
N0 = sin(2*pi*n/16+pi/10);
N1 = sqrt(2)*sin(2*pi*n/16);
N=1000;

S = rand(size(n));
S = (S - mean(S))*sqrt(0.05/var(S));
x = N1;
y = S + N0;

rxx_0 = mean(x .* x);
rxx_1 = mean(x(1:end-1) .* x(2:end));
Rxx = [rxx_0, rxx_1;
       rxx_1, rxx_0];
ryx_0 = mean(y .* x);
ryx_1 = mean(y(2:end) .* x(1:end-1));
Ryx = [ryx_0; ryx_1];
    
H_temp = zeros(2, N);        % 滤波器参数储存矩阵
J_temp = zeros(1, N);        % 均方误差储存向量
e = zeros(1,N);
H_temp(:,1) = [3;-4];

for i = 1:1:N-1
    e(i+1) = y(i+1) - H_temp(:,i).'*[x(i+1);x(i)];
    H_temp(:,i+1) = H_temp(:,i) + 0.1*e(i+1)*[x(i+1);x(i)]; % 计算下一个滤波器参数
end
for i = 1:1:N
    J_temp(i) = var(y) - 2*Ryx.'*H_temp(:,i) + H_temp(:,i).'*Rxx*H_temp(:,i);       % 计算均方误差
end

figure;
contour(h0,h1,J_n,linspace(0,2,10));        % 绘制等值曲线
hold on;
plot3(H_temp(1,1:N),H_temp(2,1:N),J_temp,LineWidth=2);
