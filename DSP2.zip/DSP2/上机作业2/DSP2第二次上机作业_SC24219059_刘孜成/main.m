clear;clc;
%% 第1题
% a)
% 设置自回归过程系数
a_1 = 0.1;
a_2 = -0.8;
A_N = [-a_1, -a_2]';

% 自相关矩阵R(N+1)设为：
% R = [r_0, r_1, r_2;
%      r_1, r_0, r_1;
%      r_2, r_1, r_0];
% 噪声功率设为：n_power

% x(n)有单位功率
r_0 = 1;

% 解方程
syms r_1 r_2 n_power;
eqns = [r_0 + a_1*r_1 + a_2*r_2 == n_power, ...
        r_1 + a_1*r_0 + a_2*r_1 == 0,...
        r_2 + a_1*r_1 + a_2*r_0 == 0];
vars = [r_1 r_2, n_power];
[r_1, r_2, n_power] = solve(eqns, vars);
r_1 = double(r_1);
r_2 = double(r_2);
n_power = double(n_power);

% 规定观测长度
N = 1000;

% 生成固定为0，方差已知的噪声
noi = rand(1, N);
noi = (noi - mean(noi))*sqrt(n_power/var(noi));

% 实现x(n), x(n) = -a_1*x(n-1) - a_2*x(n-2) + noi(n)
x = zeros(1, N);
x(1) = noi(1);
x(2) = -a_1*x(1) + noi(2);
for i = 3:N
    x(i) = -a_1*x(i-1) - a_2*x(i-2) + noi(i);
end

% 绘图
figure(1);
plot(1:N, x);
grid on;
xlabel('n');
ylabel('x(n)');



%%
% b)
% 参数设置
epoch = 100;        % 迭代轮数
N = 1000;           % 迭代次数
delta = 0.05;       % 迭代步长
filter_order = 2;   % 滤波器阶数

% 初始化
R = zeros(filter_order, N);     % 滤波器参数储存矩阵
J = zeros(1, N);                % 均方误差储存矩阵

% LMS算法
for j = 1:1:epoch
    % 每次迭代重新生成噪声
    noi = rand(1, N);
    noi = (noi - mean(noi))*sqrt(n_power/var(noi)); 
    % 生成x(n)
    x = zeros(1, N);
    x(1) = noi(1);
    x(2) = -a_1*x(1) + noi(2);
    for i = 3:N
        x(i) = -a_1*x(i-1) - a_2*x(i-2) + noi(i);
    end
    % 相关
    r_0b = mean(x.*x);
    r_1b = mean(x(1:end-1).*x(2:end));
    r_2b = mean(x(1:end-2).*x(3:end));
    Rxx_t = [r_0b, r_1b;
             r_1b, r_0b];
    % 临时储存矩阵
    R_temp = zeros(filter_order, N);
    J_temp = zeros(1, N);
    % 一次迭代
    for i = 2:1:N-1
        e = x(i+1) - R_temp(:,i).'*[x(i); x(i-1)];
        R_temp(:,i+1) = R_temp(:,i) + delta*e*[x(i); x(i-1)];
    end
    for i = 1:1:N
        J_temp(i) = var(x) - 2*[r_1b,r_2b]*R_temp(:,i) + R_temp(:,i).'*Rxx_t*R_temp(:,i);
    end
    R = R_temp/epoch + R;
    J = J_temp/epoch + J;
end

% 绘制曲线
figure(2);
plot(1:size(R,2), -R(1,:), 'r-', 1:size(R,2), -R(2,:), 'b-');
hold on;
title('100轮迭代平均');
legend('迭代100轮取平均a1','迭代100轮取平均a2');
xlabel('n');
ylabel('a1与a2的值');

% 理论时间常数
Rxx = [r_0, r_1;
       r_1, r_0];
[V,D] = eig(Rxx);
D = diag(D);
lamda_max = max(D);
lamda_min = min(D);
tau = 1/(delta*lamda_min);

% 实验时间常数
figure(3);
plot(1:size(J,2), J);
grid on;
title('100轮迭代均方差');



%%
% c)
% 误差储存向量
f = zeros(1, N);
epsilon_1 = zeros(1, N);
epsilon_2 = zeros(1, N);

% LMS算法的一次实现
% 每次迭代重新生成噪声
noi = rand(1, N);
noi = (noi - mean(noi))*sqrt(n_power/var(noi)); 
% 生成x(n)
x = zeros(1, N);
x(1) = noi(1);
x(2) = -a_1*x(1) + noi(2);
for i = 3:N
    x(i) = -a_1*x(i-1) - a_2*x(i-2) + noi(i);
end
% 相关
r_0c = mean(x.*x);
r_1c = mean(x(1:end-1).*x(2:end));
r_2c = mean(x(1:end-2).*x(3:end));
Rxx_t = [r_0c, r_1c;
         r_1c, r_0c];
% 临时储存矩阵
R_temp = zeros(filter_order, N);
J_temp = zeros(1, N);
% 一次迭代
for i = 2:1:N-1
    e = x(i+1) - R_temp(:,i).'*[x(i); x(i-1)];
    R_temp(:,i+1) = R_temp(:,i) + delta*e*[x(i); x(i-1)];
    f(i) = e;
end
for i = 1:1:N
    J_temp(i) = var(x) - 2*[r_1b,r_2b]*R_temp(:,i) + R_temp(:,i).'*Rxx_t*R_temp(:,i);
end

epsilon_1 = -a_1 - R_temp(1,:);
epsilon_2 = -a_2 - R_temp(2,:);

% 计算功率谱
pf = pwelch(f);
pepsilon_1 = pwelch(epsilon_1);
pepsilon_2 = pwelch(epsilon_2);

% 绘图
figure(4);
plot(1:N, f);
grid on;
title('预测误差f');
xlabel('n');
ylabel('f(n)');

% 绘图
figure(5);
plot(1:size(pf,1), pf', 'r-', 1:size(pf,1), pepsilon_1', 'b-', 1:size(pf,1), pepsilon_2', 'k-');
grid on;
axis([0 129 0 0.3]);
title('LMS算法的一次实现');
legend('预测误差功率谱','\epsilon_{1}功率谱', '\epsilon_{2}功率谱');
xlabel('n');




%%
% d)
f_d = zeros(1, N);
% LMS算法
for j = 1:1:epoch
    % 每次迭代重新生成噪声
    noi = rand(1, N);
    noi = (noi - mean(noi))*sqrt(n_power/var(noi)); 
    % 生成x(n)
    x = zeros(1, N);
    x(1) = noi(1);
    x(2) = -a_1*x(1) + noi(2);
    for i = 3:N
        x(i) = -a_1*x(i-1) - a_2*x(i-2) + noi(i);
    end
    % 相关
    r_0b = mean(x.*x);
    r_1b = mean(x(1:end-1).*x(2:end));
    r_2b = mean(x(1:end-2).*x(3:end));
    Rxx_t = [r_0b, r_1b;
             r_1b, r_0b];
    % 临时储存矩阵
    R_temp = zeros(filter_order, N);
    f_temp = zeros(1, N);
    % 一次迭代
    for i = 2:1:N-1
        e = x(i+1) - R_temp(:,i).'*[x(i); x(i-1)];
        R_temp(:,i+1) = R_temp(:,i) + delta*e*[x(i); x(i-1)];
        f_temp(i) = e;
    end
    R = R_temp/epoch + R;
    f_d = f_temp.^2/epoch + f_d;
end
% 绘图
plot(1:size(f_d,2), f_d);

%% 第2题
clear;clc;
% 产生信号
N = 1000;                                   % 采样点数
n = 1:N;
phi = 2*pi*rand(1);                         % 产生随即相位
x_1 = sin(0.05*pi*n + phi);                 % x_1(n)
e = 1*randn(1, N);
x_2 = zeros(1, N);
x_2(1) = e(1);
x_2(2) = e(2);
for i = 3:N
    x_2(i) = e(i) + 2*e(i-1) + e(i-2);
end
x_2 = (x_2-mean(x_2))*sqrt(1/var(x_2));     % x_2(n)，调整均值和功率
x = x_1 + x_2;                              % x(n)

% 计算序列自相关
[r_x1, lags_1] = xcorr(x_1);
[r_x2, lags_2] = xcorr(x_2);

% 绘图
figure(1);
plot(lags_1, r_x1, lags_2, r_x2);
hold on;
legend('r_x1', 'r_x2');

figure(2);
stem(lags_1, r_x1, 'b');
hold on;
stem(lags_2, r_x2, 'r');
axis([-12 12 0 1000])
title('序列自相关');
legend('r_x1', 'r_x2');

% 函数自相关
k = -7:1:7;
r_fx1 = 0.5*cos(0.05*pi*k);
r_fx2 = [0, 0, 0, 0, 0, 1, 4, 6, 4, 1, 0, 0, 0, 0, 0];
figure(3);
stem(k, r_fx1, 'b');
hold on;
stem(k, r_fx2, 'r');
title('函数自相关')
legend('r_x1', 'r_x2');

% 谱线增强
delta = 0.0000001;              % 步长
D = 5;                          % 延迟
R = 64;                         % 滤波器阶数
x_D = zeros(1, N);              % 延迟信号初始化
x_D(D+1:end) = x(1:end-D);      % 延迟信号赋值
epoch = 100;                    % 迭代轮数
H = zeros(R, 1);                % 滤波器初始化
y = zeros(1, N);                % 增强信号初始化
% LMS算法实现的线性预测误差滤波器进行谱线增强
for j = 1:1:epoch
    H_temp = zeros(R, 1);
    y_temp = zeros(1, N);
    for i = R:1:N
        xd_vec = x_D(i-R+1:i);
        y_temp(i) = H_temp.' * xd_vec.';
        e = x(i) - y(i);
        H_temp = H_temp + delta*e*xd_vec.';
    end
    H = H_temp/epoch + H;
    y = y_temp/epoch + y;
end

% 绘图
figure(4);
subplot(3, 1, 1);
plot(n, x);
title('原始信号');
subplot(3,1,2);
plot(n, y);
title('增强信号');
subplot(3,1,3);
plot(n, x_1);
title('原始窄带信号');